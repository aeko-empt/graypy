#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""unit pytests for :mod:`graypy`

.. note::

    These tests mock sending to Graylog, thus, do not require a local instance
    of Graylog to successfully run.
"""
