#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""pytests for :mod:`graypy`"""
