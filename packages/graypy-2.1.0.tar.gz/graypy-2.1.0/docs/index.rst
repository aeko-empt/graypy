.. graypy documentation master file

Welcome to graypy's documentation!
=====================================

This code is open source, and is `available on GitHub`_.

.. _available on GitHub: https://github.com/severb/graypy

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Overview<readme>
   Basic GELF Handlers<api/graypy.handler>
   RabbitMQ GELF Handler<api/graypy.rabbitmq>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
